#include <GL/glew.h>
#include <GL/freeglut.h>
#include <iostream>
#include <string>
#include <math.h>

#include "CellColors.h"
#include "board.h"

using namespace std;

void printText()
{
	std::string s = std::to_string(100);

	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, s[0]);
}

int main(int argc, char **argv)
{
	printf("\033[00;36mSuccess!\033[0m\n");

	return EXIT_SUCCESS;
}
