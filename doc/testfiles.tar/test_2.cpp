#include <GL/glew.h>
#include <GL/freeglut.h>
#include <iostream>
#include <string>
#include <math.h>

#include "CellColors.h"
#include "board.h"

using namespace std;

void printText(bool setPosition, GLint x, GLint y, std::string e, GLubyte red, GLubyte green, GLubyte blue)
{
	std::string s = std::to_string(100);

	glColor3ub(red, green, blue);

	if (setPosition)
	{
		glRasterPos2i(x, y);
	}

	for (size_t i = 0; i < s.size(); ++i)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, s[i]);
	}
}

int main(int argc, char **argv)
{
	printf("\033[22;34mSuccess!\033[0m\n");

	return EXIT_SUCCESS;
}
